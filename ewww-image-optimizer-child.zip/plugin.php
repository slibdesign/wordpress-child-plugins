<?php
/*
 * Plugin Name:       EWWW Image Optimizer Child Plugin
 * Plugin URI:        https://childpluginwp.com/ewww-image-optimizer-child/
 * Description:       ID 88 ewww-image-optimizer-child.zip WordPress child plugin for v8.0.0+ EWWW Image Optimizer
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       ewww-image-optimizer-child
 * Domain Path:       /languages
 * Requires Plugins:  ewww-image-optimizer
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 88 ewww-image-optimizer-child version 1.0.1
 * Dependancy: EWWW Image Optimizer
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingewww_image_optimizer_88")) != 1) 
{
	function plugin_files_ewww_image_optimizer_88()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("ewww_image_optimizer_88-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("ewww_image_optimizer_88-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_ewww_image_optimizer_88", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlewww_image_optimizer_88") != 1)
{
	function plugin_sourceewww_image_optimizer_88()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourceewww_image_optimizer_88", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingsewww_image_optimizer_88() 
{ 
	register_setting("plugin_options_pageewww_image_optimizer_88", "plugin_settingewww_image_optimizer_88", "wdl_callbackewww_image_optimizer_88");
    register_setting("plugin_options_pageewww_image_optimizer_88", "plugin_setting_htmlewww_image_optimizer_88", "wdl_callbackewww_image_optimizer_88");
}
add_action("admin_init", "plugin_register_settingsewww_image_optimizer_88");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pageewww_image_optimizer_88() 
{
	add_options_page("EWWW Image Optimizer Child Plugin Settings", "EWWW Image Optimizer Child Plugin Settings", "manage_options", "pluginvendorewww_image_optimizer_88", "plugin_register_options_page_formewww_image_optimizer_88");
}
add_action("admin_menu", "plugin_register_options_pageewww_image_optimizer_88");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formewww_image_optimizer_88()
{ 
?>
<div>
	<h1>EWWW Image Optimizer Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pageewww_image_optimizer_88"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingewww_image_optimizer_88" value="1" <?php if((get_option("plugin_settingewww_image_optimizer_88") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlewww_image_optimizer_88" value="1" <?php if((get_option("plugin_setting_htmlewww_image_optimizer_88") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
