<?php
/*
 * Plugin Name:       Redirection Child Plugin
 * Plugin URI:        https://childpluginwp.com/redirection-child/
 * Description:       ID 51 redirection-child.zip WordPress child plugin for v5.5.1+ Redirection
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       redirection-child
 * Domain Path:       /languages
 * Requires Plugins:  redirection
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 51 redirection-child version 1.0.1
 * Dependancy: Redirection
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingredirection_51")) != 1) 
{
	function plugin_files_redirection_51()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("redirection_51-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("redirection_51-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_redirection_51", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlredirection_51") != 1)
{
	function plugin_sourceredirection_51()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourceredirection_51", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingsredirection_51() 
{ 
	register_setting("plugin_options_pageredirection_51", "plugin_settingredirection_51", "wdl_callbackredirection_51");
    register_setting("plugin_options_pageredirection_51", "plugin_setting_htmlredirection_51", "wdl_callbackredirection_51");
}
add_action("admin_init", "plugin_register_settingsredirection_51");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pageredirection_51() 
{
	add_options_page("Redirection Child Plugin Settings", "Redirection Child Plugin Settings", "manage_options", "pluginvendorredirection_51", "plugin_register_options_page_formredirection_51");
}
add_action("admin_menu", "plugin_register_options_pageredirection_51");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formredirection_51()
{ 
?>
<div>
	<h1>Redirection Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pageredirection_51"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingredirection_51" value="1" <?php if((get_option("plugin_settingredirection_51") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlredirection_51" value="1" <?php if((get_option("plugin_setting_htmlredirection_51") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
