=== insert-headers-and-footers-child ===
Contributors: childpluginwp
Tags: plugins, insert-headers-and-footers-child, insert-headers-and-footers-child.zip, plugin-zip, download, zip, wordpress, admin, code, development
Requires at least: 2.7
Tested up to: 6.7
Stable tag: 1.0.1
License: GPLv3

WordPress plugin ID: 52 for WPCode &#8211; Insert Headers and Footers   Custom Code Snippets &#8211; WordPress Code Manager v 2.2.4.1+ WordPress plugin.

[A framework for WP plugin modification](https://childpluginwp.com) 

Customise WordPress plugins with Child Plugin WP child plugins.

== Description ==

= WPCode &#8211; Insert Headers and Footers   Custom Code Snippets &#8211; WordPress Code Manager Plugin for WordPress =

**Feature additions**: extend commercial and freemium WordPress plugins without modifying the original plugin code base add hooks do_action( string $hook_name, mixed $arg) and add filters add_filter( string $hook_name, callable $callback, int $priority = 10, int $accepted_args = 1 )

**Plugin updates**: continue to receive parent plugin updates from the plugin author

**Version control**: create plugin versions and eliminate archive control on parent plugins

**Code repositories**: share you code

**Redeploy**: Deploy updates to other WordPress websites quickly

[About plugin framework](https://childpluginwp.com)

= Features =

Enqueued stylesheet: containing no style

Enqueued JavaScript file: jQuery ready

Dashboard Settings page: with two temporary form options

PHP: insert-headers-and-footers-child text domain specifically for plugin callbacks and a requires plugin definition

= Plugin Link =

[insert-headers-and-footers-child WordPress plugin ID: 52](https://childpluginwp.com/insert-headers-and-footers-child/)
 
= Starter Guide =

[Checkout Download plugin guide](https://childpluginwp.com) for more information.

== Installation ==

Activate the plugin through the 'Plugins' menu in WordPress.

or

Extract the zipped file and upload the folder `insert-headers-and-footers-child` to `/wp-content/plugins/` directory.

== Changelog ==

= 1.0.1 - 23 January 2025 =
* UI Changes

= 1.0.0 - 21 December 2024 =
* Initial Release