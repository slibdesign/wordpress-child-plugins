<?php
/*
 * Plugin Name:       Duplicator Child Plugin
 * Plugin URI:        https://childpluginwp.com/duplicator-child/
 * Description:       ID 66 duplicator-child.zip for v1.5.11.2+ Duplicator
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       duplicator-child
 * Domain Path:       /languages
 * Requires Plugins:  duplicator
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 66 duplicator-child version 1.0.1
 * Dependancy: Duplicator
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingduplicator_66")) != 1) 
{
	function plugin_files_duplicator_66()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("duplicator_66-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("duplicator_66-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_duplicator_66", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlduplicator_66") != 1)
{
	function plugin_sourceduplicator_66()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourceduplicator_66", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingsduplicator_66() 
{ 
	register_setting("plugin_options_pageduplicator_66", "plugin_settingduplicator_66", "wdl_callbackduplicator_66");
    register_setting("plugin_options_pageduplicator_66", "plugin_setting_htmlduplicator_66", "wdl_callbackduplicator_66");
}
add_action("admin_init", "plugin_register_settingsduplicator_66");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pageduplicator_66() 
{
	add_options_page("Duplicator Child Plugin Settings", "Duplicator Child Plugin Settings", "manage_options", "pluginvendorduplicator_66", "plugin_register_options_page_formduplicator_66");
}
add_action("admin_menu", "plugin_register_options_pageduplicator_66");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formduplicator_66()
{ 
?>
<div>
	<h1>Duplicator Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pageduplicator_66"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingduplicator_66" value="1" <?php if((get_option("plugin_settingduplicator_66") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlduplicator_66" value="1" <?php if((get_option("plugin_setting_htmlduplicator_66") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
