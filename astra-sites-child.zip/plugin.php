<?php
/*
 * Plugin Name:       Astra sites Child Plugin
 * Plugin URI:        https://childpluginwp.com/astra-sites-child/
 * Description:       ID 61 astra-sites-child.zip for v4.4.10+ Astra sites
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       astra-sites-child
 * Domain Path:       /languages
 * Requires Plugins:  astra-sites
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 61 astra-sites-child version 1.0.1
 * Dependancy: Astra sites
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingastra_sites_61")) != 1) 
{
	function plugin_files_astra_sites_61()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("astra_sites_61-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("astra_sites_61-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_astra_sites_61", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlastra_sites_61") != 1)
{
	function plugin_sourceastra_sites_61()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourceastra_sites_61", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingsastra_sites_61() 
{ 
	register_setting("plugin_options_pageastra_sites_61", "plugin_settingastra_sites_61", "wdl_callbackastra_sites_61");
    register_setting("plugin_options_pageastra_sites_61", "plugin_setting_htmlastra_sites_61", "wdl_callbackastra_sites_61");
}
add_action("admin_init", "plugin_register_settingsastra_sites_61");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pageastra_sites_61() 
{
	add_options_page("Astra sites Child Plugin Settings", "Astra sites Child Plugin Settings", "manage_options", "pluginvendorastra_sites_61", "plugin_register_options_page_formastra_sites_61");
}
add_action("admin_menu", "plugin_register_options_pageastra_sites_61");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formastra_sites_61()
{ 
?>
<div>
	<h1>Astra sites Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pageastra_sites_61"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingastra_sites_61" value="1" <?php if((get_option("plugin_settingastra_sites_61") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlastra_sites_61" value="1" <?php if((get_option("plugin_setting_htmlastra_sites_61") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
