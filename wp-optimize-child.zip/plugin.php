<?php
/*
 * Plugin Name:       Wp optimize Child Plugin
 * Plugin URI:        https://childpluginwp.com/wp-optimize-child/
 * Description:       ID 81 wp-optimize-child.zip for v3.8.0+ Wp optimize
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       wp-optimize-child
 * Domain Path:       /languages
 * Requires Plugins:  wp-optimize
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 81 wp-optimize-child version 1.0.1
 * Dependancy: Wp optimize
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingwp_optimize_81")) != 1) 
{
	function plugin_files_wp_optimize_81()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("wp_optimize_81-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("wp_optimize_81-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_wp_optimize_81", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlwp_optimize_81") != 1)
{
	function plugin_sourcewp_optimize_81()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourcewp_optimize_81", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingswp_optimize_81() 
{ 
	register_setting("plugin_options_pagewp_optimize_81", "plugin_settingwp_optimize_81", "wdl_callbackwp_optimize_81");
    register_setting("plugin_options_pagewp_optimize_81", "plugin_setting_htmlwp_optimize_81", "wdl_callbackwp_optimize_81");
}
add_action("admin_init", "plugin_register_settingswp_optimize_81");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pagewp_optimize_81() 
{
	add_options_page("Wp optimize Child Plugin Settings", "Wp optimize Child Plugin Settings", "manage_options", "pluginvendorwp_optimize_81", "plugin_register_options_page_formwp_optimize_81");
}
add_action("admin_menu", "plugin_register_options_pagewp_optimize_81");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formwp_optimize_81()
{ 
?>
<div>
	<h1>Wp optimize Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pagewp_optimize_81"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingwp_optimize_81" value="1" <?php if((get_option("plugin_settingwp_optimize_81") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlwp_optimize_81" value="1" <?php if((get_option("plugin_setting_htmlwp_optimize_81") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
