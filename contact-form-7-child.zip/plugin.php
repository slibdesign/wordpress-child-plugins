<?php
/*
 * Plugin Name:       Contact Form 7 Child Plugin
 * Plugin URI:        https://childpluginwp.com/contact-form-7-child/
 * Description:       ID 31 contact-form-7-child.zip WordPress child plugin for v6.0.1+ Contact Form 7
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       contact-form-7-child
 * Domain Path:       /languages
 * Requires Plugins:  contact-form-7
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 31 contact-form-7-child version 1.0.1
 * Dependancy: Contact Form 7
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingcontact_form_7_31")) != 1) 
{
	function plugin_files_contact_form_7_31()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("contact_form_7_31-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("contact_form_7_31-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_contact_form_7_31", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlcontact_form_7_31") != 1)
{
	function plugin_sourcecontact_form_7_31()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourcecontact_form_7_31", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingscontact_form_7_31() 
{ 
	register_setting("plugin_options_pagecontact_form_7_31", "plugin_settingcontact_form_7_31", "wdl_callbackcontact_form_7_31");
    register_setting("plugin_options_pagecontact_form_7_31", "plugin_setting_htmlcontact_form_7_31", "wdl_callbackcontact_form_7_31");
}
add_action("admin_init", "plugin_register_settingscontact_form_7_31");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pagecontact_form_7_31() 
{
	add_options_page("Contact Form 7 Child Plugin Settings", "Contact Form 7 Child Plugin Settings", "manage_options", "pluginvendorcontact_form_7_31", "plugin_register_options_page_formcontact_form_7_31");
}
add_action("admin_menu", "plugin_register_options_pagecontact_form_7_31");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formcontact_form_7_31()
{ 
?>
<div>
	<h1>Contact Form 7 Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pagecontact_form_7_31"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingcontact_form_7_31" value="1" <?php if((get_option("plugin_settingcontact_form_7_31") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlcontact_form_7_31" value="1" <?php if((get_option("plugin_setting_htmlcontact_form_7_31") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
