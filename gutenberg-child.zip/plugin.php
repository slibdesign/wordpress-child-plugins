<?php
/*
 * Plugin Name:       Gutenberg Child Plugin
 * Plugin URI:        https://childpluginwp.com/gutenberg-child/
 * Description:       ID 222 gutenberg-child.zip WordPress child plugin for v19.9.0+ Gutenberg
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       gutenberg-child
 * Domain Path:       /languages
 * Requires Plugins:  gutenberg
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 222 gutenberg-child version 1.0.1
 * Dependancy: Gutenberg
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settinggutenberg_222")) != 1) 
{
	function plugin_files_gutenberg_222()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("gutenberg_222-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("gutenberg_222-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_gutenberg_222", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlgutenberg_222") != 1)
{
	function plugin_sourcegutenberg_222()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourcegutenberg_222", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingsgutenberg_222() 
{ 
	register_setting("plugin_options_pagegutenberg_222", "plugin_settinggutenberg_222", "wdl_callbackgutenberg_222");
    register_setting("plugin_options_pagegutenberg_222", "plugin_setting_htmlgutenberg_222", "wdl_callbackgutenberg_222");
}
add_action("admin_init", "plugin_register_settingsgutenberg_222");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pagegutenberg_222() 
{
	add_options_page("Gutenberg Child Plugin Settings", "Gutenberg Child Plugin Settings", "manage_options", "pluginvendorgutenberg_222", "plugin_register_options_page_formgutenberg_222");
}
add_action("admin_menu", "plugin_register_options_pagegutenberg_222");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formgutenberg_222()
{ 
?>
<div>
	<h1>Gutenberg Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pagegutenberg_222"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settinggutenberg_222" value="1" <?php if((get_option("plugin_settinggutenberg_222") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlgutenberg_222" value="1" <?php if((get_option("plugin_setting_htmlgutenberg_222") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
