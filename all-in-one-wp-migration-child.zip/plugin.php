<?php
/*
 * Plugin Name:       All in one wp migration Child Plugin
 * Plugin URI:        https://childpluginwp.com/all-in-one-wp-migration-child/
 * Description:       ID 38 all-in-one-wp-migration-child.zip for v7.87+ All in one wp migration
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            childpluginwp
 * Author URI:        https://childpluginwp.com
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       all-in-one-wp-migration-child
 * Domain Path:       /languages
 * Requires Plugins:  all-in-one-wp-migration
 */
 
/*
 * -----------------------------------------------------------------------------------------------------
 * ID: 38 all-in-one-wp-migration-child version 1.0.1
 * Dependancy: All in one wp migration
 * -----------------------------------------------------------------------------------------------------
 */
  
 
/* 
 * WP plugin .css and .js files to enqueue AND WP plugin options page. If form option: 2 is set = respond
 */

if((get_option("plugin_settingall_in_one_wp_migration_38")) != 1) 
{
	function plugin_files_all_in_one_wp_migration_38()
	{
		$plugin_url = plugin_dir_url(__FILE__);

		wp_enqueue_style("all_in_one_wp_migration_38-stylesheet", $plugin_url . "css/style.css");
		wp_enqueue_script("all_in_one_wp_migration_38-script", $plugin_url . "js/scripts.js", array("jquery"), "1.0.0", true);
	}
	add_action("wp_enqueue_scripts", "plugin_files_all_in_one_wp_migration_38", 80);
}


/* 
 * WP plugin options page. If form option: 2 is set = respond
 */

if(get_option("plugin_setting_htmlall_in_one_wp_migration_38") != 1)
{
	function plugin_sourceall_in_one_wp_migration_38()
	{
		if((is_home()) || (is_front_page()))
		{
		?>
			<p style="text-align:center;"><a href="https://childpluginwp.com">childpluginwp.com</a></p>
		<?php
		}
	}
	add_action("wp_footer", "plugin_sourceall_in_one_wp_migration_38", 9);
}


/* 
 * WP plugin options page settings
 */

function plugin_register_settingsall_in_one_wp_migration_38() 
{ 
	register_setting("plugin_options_pageall_in_one_wp_migration_38", "plugin_settingall_in_one_wp_migration_38", "wdl_callbackall_in_one_wp_migration_38");
    register_setting("plugin_options_pageall_in_one_wp_migration_38", "plugin_setting_htmlall_in_one_wp_migration_38", "wdl_callbackall_in_one_wp_migration_38");
}
add_action("admin_init", "plugin_register_settingsall_in_one_wp_migration_38");


/* 
 * WP plugin options page menu 
 */

function plugin_register_options_pageall_in_one_wp_migration_38() 
{
	add_options_page("All in one wp migration Child Plugin Settings", "All in one wp migration Child Plugin Settings", "manage_options", "pluginvendorall_in_one_wp_migration_38", "plugin_register_options_page_formall_in_one_wp_migration_38");
}
add_action("admin_menu", "plugin_register_options_pageall_in_one_wp_migration_38");


/*
 * WP Dashboard plugin settings page html
 */

function plugin_register_options_page_formall_in_one_wp_migration_38()
{ 
?>
<div>
	<h1>All in one wp migration Child Plugin Settings</h1>
	<p>A framework for WP plugin modification <a href="https://childpluginwp.com">childpluginwp.com</a></p>
	<form method="post" action="options.php">
		<?php settings_fields("plugin_options_pageall_in_one_wp_migration_38"); ?>
		<p><label><input size="10" type="checkbox" name="plugin_settingall_in_one_wp_migration_38" value="1" <?php if((get_option("plugin_settingall_in_one_wp_migration_38") == 1)) { echo " checked "; } ?> > Tick to disable the .css and .js plugin files<label></p>
        <p><label><input size="10" type="checkbox" name="plugin_setting_htmlall_in_one_wp_migration_38" value="1" <?php if((get_option("plugin_setting_htmlall_in_one_wp_migration_38") == 1)) { echo " checked "; } ?> > Tick to disable the author footer link</p>
		<?php submit_button(); ?>
	</form>
</div>
<?php
}


/*
 * WP Dashboard PHP mySQL version toolkit
 */

if(!function_exists("footer_toolkit_placement")) 
{
	
	function footer_toolkit_placement() 
	{
		add_filter("admin_footer_text", "footer_toolkit", 12);
	}

	function footer_toolkit($content) 
	{
		$fullver = mysqli_get_server_info(mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME));
		$pattern = "/^5.5.5-/i";
		$mysqlver = preg_replace($pattern, "", $fullver);

		define("mysqlversion", $mysqlver);
		define("phpversion", phpversion());
		define("wpversion", get_bloginfo("version"));

		return ("Plugin installed <a href=\"https://childpluginwp.com\">childpluginwp.com</a>") . " A framework for WP plugin modification. WordPress version: " . esc_attr(wpversion) . " mySQL version: " . esc_attr(mysqlversion) . " PHP version: " . esc_attr(phpversion) . ".";

	}
	add_action("admin_init", "footer_toolkit_placement");
}
